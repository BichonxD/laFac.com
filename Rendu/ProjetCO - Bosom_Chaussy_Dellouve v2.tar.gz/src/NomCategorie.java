package laFac;

public enum NomCategorie
{
	Culture, Hightech;
}
