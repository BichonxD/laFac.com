package laFac;

public enum NomStatut
{
	Employe, Adherent, Visiteur;
}
